from __future__ import annotations

import json
import math
import re
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from io import BytesIO
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo

import pandas as pd
import requests


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OUTPUTS = ROOT / "outputs"
SHANGHAI = ZoneInfo("Asia/Shanghai")
RUN_AT = datetime.now(SHANGHAI)
ASOF_DATE = RUN_AT.date()
VALUATION_TIME = RUN_AT.replace(tzinfo=None)
RISK_FREE = 0.0115
RISK_FREE_META = {
    "value": RISK_FREE,
    "as_of": "2026-08-07",
    "source": "短端无风险利率模型假设（未作为行情事实）",
    "verified": False,
}

# 上交所公布的2026年A股市场休市日。周末由 is_trading_day 单独处理。
OFFICIAL_CLOSED_DATES_2026 = {
    date(2026, 1, 1), date(2026, 1, 2),
    date(2026, 2, 16), date(2026, 2, 17), date(2026, 2, 18), date(2026, 2, 19),
    date(2026, 2, 20), date(2026, 2, 23),
    date(2026, 4, 6),
    date(2026, 5, 1), date(2026, 5, 4), date(2026, 5, 5),
    date(2026, 6, 19),
    date(2026, 9, 25),
    date(2026, 10, 1), date(2026, 10, 2), date(2026, 10, 5), date(2026, 10, 6), date(2026, 10, 7),
}
UNDERLYINGS = {
    "510050": {"exchange": "SSE", "symbol": "sh510050", "name": "上证50ETF"},
    "510300": {"exchange": "SSE", "symbol": "sh510300", "name": "沪深300ETF"},
    "510500": {"exchange": "SSE", "symbol": "sh510500", "name": "中证500ETF"},
    "159915": {"exchange": "SZSE", "symbol": "sz159915", "name": "创业板ETF"},
    "588000": {"exchange": "SSE", "symbol": "sh588000", "name": "科创50ETF"},
}

SESSION = requests.Session()
SESSION.headers.update(
    {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
        "Referer": "https://finance.sina.com.cn/",
    }
)


@dataclass
class Option:
    underlying: str
    exchange: str
    security_id: str
    contract_id: str
    name: str
    cp: str
    strike: float
    expiry: str
    unit: int
    bid: float
    ask: float
    bid_qty: int
    ask_qty: int
    last: float
    volume: int
    oi: int
    quote_date: str
    adjusted: bool = False
    suspended: bool = False
    official_oi: int | None = None
    vendor_iv: float | None = None
    vendor_delta: float | None = None
    vendor_gamma: float | None = None
    vendor_theta: float | None = None
    vendor_vega: float | None = None
    iv: float | None = None
    delta: float | None = None
    gamma: float | None = None
    theta: float | None = None
    vega: float | None = None
    q: float | None = None
    official_bid: float | None = None
    official_ask: float | None = None
    official_time: str | None = None
    official_verified: bool = False
    eastmoney_last: float | None = None
    arbitrage_ok: bool = True
    arbitrage_notes: list[str] = field(default_factory=list)
    bid_levels: list[tuple[float, int]] = field(default_factory=list)
    ask_levels: list[tuple[float, int]] = field(default_factory=list)

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2 if self.bid > 0 and self.ask > 0 else self.last

    @property
    def rel_spread(self) -> float:
        m = self.mid
        return (self.ask - self.bid) / m if m > 0 and self.ask >= self.bid else float("inf")

    @property
    def dte(self) -> int:
        return (date.fromisoformat(self.expiry) - ASOF_DATE).days


def is_trading_day(value: date) -> bool:
    if value.weekday() >= 5:
        return False
    if value.year == 2026:
        return value not in OFFICIAL_CLOSED_DATES_2026
    return False


def remaining_years(expiry: str, valuation: datetime | None = None) -> float:
    valuation = valuation or VALUATION_TIME
    expiry_time = datetime.combine(date.fromisoformat(expiry), datetime.min.time()).replace(hour=15)
    return max((expiry_time - valuation).total_seconds() / (365.0 * 86400.0), 1.0 / (365.0 * 24.0))


def parse_source_datetime(value: Any) -> datetime | None:
    text = str(value or "").strip()
    digits = re.sub(r"\D", "", text)
    for fmt, size in (("%Y%m%d%H%M%S", 14), ("%Y%m%d", 8)):
        if len(digits) >= size:
            try:
                return datetime.strptime(digits[:size], fmt)
            except ValueError:
                pass
    return None


def capture_slot_for(valuation: datetime) -> str:
    minute = valuation.hour * 60 + valuation.minute
    slots = [(585, "09:45"), (690, "11:30"), (810, "13:30"), (870, "14:30"), (900, "15:00")]
    eligible = [label for cutoff, label in slots if minute >= cutoff]
    return eligible[-1] if eligible else "09:45"


def safe_float(value: Any) -> float | None:
    try:
        x = float(value)
        if not math.isfinite(x):
            return None
        return x
    except (TypeError, ValueError):
        return None


def safe_int(value: Any) -> int:
    x = safe_float(value)
    return int(x) if x is not None else 0


def get(url: str, *, referer: str | None = None, timeout: int = 30) -> requests.Response:
    headers = {"Referer": referer} if referer else None
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            response = SESSION.get(url, headers=headers, timeout=timeout)
            response.raise_for_status()
            return response
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            if attempt < 2:
                time.sleep(0.4 * (attempt + 1))
    raise RuntimeError(f"GET failed: {url}: {last_error}")


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def bs_price(cp: str, s: float, k: float, t: float, r: float, q: float, sigma: float) -> float:
    if t <= 1e-10 or sigma <= 1e-10:
        return max(s - k, 0.0) if cp == "C" else max(k - s, 0.0)
    st = math.sqrt(t)
    d1 = (math.log(s / k) + (r - q + 0.5 * sigma * sigma) * t) / (sigma * st)
    d2 = d1 - sigma * st
    if cp == "C":
        return s * math.exp(-q * t) * norm_cdf(d1) - k * math.exp(-r * t) * norm_cdf(d2)
    return k * math.exp(-r * t) * norm_cdf(-d2) - s * math.exp(-q * t) * norm_cdf(-d1)


def bs_greeks(cp: str, s: float, k: float, t: float, r: float, q: float, sigma: float) -> dict[str, float]:
    if t <= 1e-10 or sigma <= 1e-10:
        delta = 1.0 if cp == "C" and s > k else (-1.0 if cp == "P" and s < k else 0.0)
        return {"delta": delta, "gamma": 0.0, "theta": 0.0, "vega": 0.0}
    st = math.sqrt(t)
    d1 = (math.log(s / k) + (r - q + 0.5 * sigma * sigma) * t) / (sigma * st)
    d2 = d1 - sigma * st
    disc_q = math.exp(-q * t)
    disc_r = math.exp(-r * t)
    gamma = disc_q * norm_pdf(d1) / (s * sigma * st)
    vega = s * disc_q * norm_pdf(d1) * st
    common = -s * disc_q * norm_pdf(d1) * sigma / (2.0 * st)
    if cp == "C":
        delta = disc_q * norm_cdf(d1)
        theta = common - r * k * disc_r * norm_cdf(d2) + q * s * disc_q * norm_cdf(d1)
    else:
        delta = -disc_q * norm_cdf(-d1)
        theta = common + r * k * disc_r * norm_cdf(-d2) - q * s * disc_q * norm_cdf(-d1)
    return {"delta": delta, "gamma": gamma, "theta": theta, "vega": vega}


def implied_vol(cp: str, target: float, s: float, k: float, t: float, r: float, q: float) -> float | None:
    intrinsic_lb = max(s * math.exp(-q * t) - k * math.exp(-r * t), 0.0) if cp == "C" else max(k * math.exp(-r * t) - s * math.exp(-q * t), 0.0)
    upper = s * math.exp(-q * t) if cp == "C" else k * math.exp(-r * t)
    if target < intrinsic_lb - 5e-5 or target > upper + 5e-5 or target <= 0:
        return None
    lo, hi = 0.001, 3.0
    plo = bs_price(cp, s, k, t, r, q, lo)
    phi = bs_price(cp, s, k, t, r, q, hi)
    if not (plo - 1e-8 <= target <= phi + 1e-8):
        return None
    for _ in range(90):
        mid = (lo + hi) / 2
        pmid = bs_price(cp, s, k, t, r, q, mid)
        if pmid < target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def fetch_spots() -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    symbols = ",".join(info["symbol"] for info in UNDERLYINGS.values())
    r = get(f"https://qt.gtimg.cn/q={symbols}", referer="https://gu.qq.com/")
    r.encoding = "gbk"
    tencent: dict[str, dict[str, Any]] = {}
    for line in r.text.strip().splitlines():
        m = re.search(r'v_(?:sh|sz)(\d+)="(.*)";', line)
        if not m:
            continue
        code, body = m.groups()
        f = body.split("~")
        tencent[code] = {
            "name": f[1],
            "last": safe_float(f[3]),
            "prev": safe_float(f[4]),
            "open": safe_float(f[5]),
            "volume": safe_int(f[6]),
            "bid": safe_float(f[9]),
            "ask": safe_float(f[19]),
            "time": f[30],
            "change": safe_float(f[31]),
            "pct": safe_float(f[32]),
            "high": safe_float(f[33]),
            "low": safe_float(f[34]),
        }
    secondary: dict[str, dict[str, Any]] = {}
    secondary_source = "东方财富"
    try:
        secids = ",".join(("0." if code == "159915" else "1.") + code for code in UNDERLYINGS)
        url = (
            "https://push2.eastmoney.com/api/qt/ulist.np/get?secids=" + secids
            + "&fields=f12,f14,f2,f3,f4,f5,f6,f15,f16,f17,f18,f124"
        )
        em = get(url, referer="https://quote.eastmoney.com/").json()["data"]["diff"]
        for row in em:
            scale = 1000.0
            secondary[row["f12"]] = {
                "name": row.get("f14"),
                "last": row.get("f2") / scale,
                "pct": row.get("f3") / 100,
                "change": row.get("f4") / scale,
                "volume": row.get("f5"),
                "amount": row.get("f6"),
                "high": row.get("f15") / scale,
                "low": row.get("f16") / scale,
                "open": row.get("f17") / scale,
                "prev": row.get("f18") / scale,
                "time": datetime.fromtimestamp(row.get("f124"), SHANGHAI).strftime("%Y-%m-%d %H:%M:%S"),
            }
    except Exception:  # Eastmoney occasionally rejects Python clients; use independent Sina spot instead.
        secondary_source = "新浪"
        sina_symbols = ",".join(info["symbol"] for info in UNDERLYINGS.values())
        sr = get(f"https://hq.sinajs.cn/list={sina_symbols}", referer="https://finance.sina.com.cn/")
        sr.encoding = "gbk"
        for line in sr.text.strip().splitlines():
            m = re.match(r'var hq_str_(?:sh|sz)(\d+)="(.*)";', line)
            if not m:
                continue
            code, body = m.groups()
            f = body.split(",")
            secondary[code] = {
                "name": f[0],
                "last": safe_float(f[3]),
                "open": safe_float(f[1]),
                "prev": safe_float(f[2]),
                "high": safe_float(f[4]),
                "low": safe_float(f[5]),
                "volume": safe_int(f[8]),
                "amount": safe_float(f[9]),
                "pct": ((safe_float(f[3]) or 0) / (safe_float(f[2]) or 1) - 1) * 100,
                "change": (safe_float(f[3]) or 0) - (safe_float(f[2]) or 0),
                "time": f"{f[30]} {f[31]}",
            }
    spots: dict[str, dict[str, Any]] = {}
    for code in UNDERLYINGS:
        tq, eq = tencent[code], secondary[code]
        tol = max(0.001, statistics.median([tq["last"], eq["last"]]) * 0.0002)
        # 腾讯 f6 是“手”（每手100份），新浪/东财为“份”。统一成份后再核验。
        primary_volume_shares = tq["volume"] * 100
        secondary_volume_raw = safe_int(eq.get("volume"))
        secondary_volume_shares = secondary_volume_raw * 100 if secondary_source == "东方财富" else secondary_volume_raw
        volume_validated = (
            secondary_volume_shares > 0
            and abs(primary_volume_shares - secondary_volume_shares) <= max(100, secondary_volume_shares * 0.0001)
        )
        spots[code] = {
            **tq,
            "volume_raw": tq["volume"],
            "volume_raw_unit": "手（100份）",
            "volume": primary_volume_shares,
            "volume_unit": "份",
            "secondary_volume": secondary_volume_shares,
            "secondary_volume_raw": secondary_volume_raw,
            "secondary_volume_raw_unit": "手（100份）" if secondary_source == "东方财富" else "份",
            "volume_validated": volume_validated,
            "secondary_source": secondary_source,
            "secondary_last": eq["last"],
            "secondary_time": eq["time"],
            "source_diff": abs(tq["last"] - eq["last"]),
            "source_tol": tol,
            "validated": abs(tq["last"] - eq["last"]) <= tol,
            "amount": eq["amount"],
        }
    return spots, {"tencent": tencent, "secondary_source": secondary_source, "secondary": secondary}


def fetch_sse_metadata() -> dict[str, dict[str, Any]]:
    url = (
        "http://query.sse.com.cn/commonQuery.do?isPagination=false&expireDate=&securityId="
        "&sqlId=SSE_ZQPZ_YSP_GGQQZSXT_XXPL_DRHY_SEARCH_L"
    )
    data = get(url, referer="https://www.sse.com.cn/assortment/options/contract/").json()["result"]
    out: dict[str, dict[str, Any]] = {}
    for row in data:
        code_m = re.search(r"\((\d{6})\)", str(row.get("SECURITYNAMEBYID", "")))
        if not code_m or code_m.group(1) not in UNDERLYINGS:
            continue
        sid = str(row["SECURITY_ID"])
        out[sid] = {
            "underlying": code_m.group(1),
            "contract_id": row.get("CONTRACT_ID", ""),
            "name": row.get("CONTRACT_SYMBOL", ""),
            "cp": "C" if row.get("CALL_OR_PUT") == "认购" else "P",
            "strike": float(row["EXERCISE_PRICE"]),
            "expiry": datetime.strptime(row["EXPIRE_DATE"], "%Y%m%d").date().isoformat(),
            "unit": int(float(row["CONTRACT_UNIT"])),
            "adjusted": row.get("CONTRACTFLAG") != "否" or row.get("CHANGEFLAG") != "否",
            "suspended": row.get("DELISTFLAG") != "否",
            "timesave": row.get("TIMESAVE"),
        }
    return out


def fetch_szse_metadata() -> dict[str, dict[str, Any]]:
    url = "https://www.sse.org.cn/api/report/ShowReport?SHOWTYPE=xlsx&CATALOGID=option_drhy&TABKEY=tab1"
    content = get(url, referer="https://www.szse.cn/option/quotation/contract/daycontract/index.html").content
    df = pd.read_excel(BytesIO(content))
    out: dict[str, dict[str, Any]] = {}
    for _, row in df.iterrows():
        target = str(row.get("标的证券简称(代码)", ""))
        if "159915" not in target:
            continue
        sid = str(int(row["合约编码"]))
        out[sid] = {
            "underlying": "159915",
            "contract_id": str(row["合约代码"]),
            "name": str(row["合约简称"]),
            "cp": "C" if row["合约类型"] == "认购" else "P",
            "strike": float(row["行权价"]),
            "expiry": pd.to_datetime(row["到期日"]).date().isoformat(),
            "unit": int(row["合约单位"]),
            "adjusted": str(row.get("合约调整", "否")) != "否",
            "suspended": str(row.get("停牌", "否")) != "否",
            "timesave": pd.to_datetime(row["交易日期"]).date().isoformat(),
            "official_oi": safe_int(row.get("合约总持仓")),
        }
    return out


def chain_codes(underlying: str, yymm: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for cp, word in (("C", "UP"), ("P", "DOWN")):
        url = f"https://hq.sinajs.cn/list=OP_{word}_{underlying}{yymm}"
        text = get(url, referer="https://stock.finance.sina.com.cn/").text
        for code in re.findall(r"CON_OP_(\d+)", text):
            out[code] = cp
    return out


def parse_sina_lines(text: str) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for line in text.strip().splitlines():
        m = re.match(r'var hq_str_([^=]+)="(.*)";', line.strip())
        if m:
            out[m.group(1)] = m.group(2).split(",")
    return out


def batched(values: list[str], n: int) -> Iterable[list[str]]:
    for i in range(0, len(values), n):
        yield values[i : i + n]


def fetch_sina_quotes(codes: list[str]) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    quote: dict[str, list[str]] = {}
    greeks: dict[str, list[str]] = {}
    for batch in batched(codes, 35):
        symbols = []
        for code in batch:
            symbols.extend([f"CON_OP_{code}", f"CON_SO_{code}"])
        text = get("https://hq.sinajs.cn/list=" + ",".join(symbols), referer="https://stock.finance.sina.com.cn/").text
        parsed = parse_sina_lines(text)
        for code in batch:
            if f"CON_OP_{code}" in parsed:
                quote[code] = parsed[f"CON_OP_{code}"]
            if f"CON_SO_{code}" in parsed:
                greeks[code] = parsed[f"CON_SO_{code}"]
    return quote, greeks


def build_options(spots: dict[str, dict[str, Any]], sse_meta: dict[str, Any], sz_meta: dict[str, Any]) -> tuple[dict[str, list[Option]], dict[str, Any]]:
    all_meta = {**sse_meta, **sz_meta}
    selected_expiries: dict[str, list[str]] = {}
    for underlying in UNDERLYINGS:
        exps = sorted(
            {
                row["expiry"]
                for row in all_meta.values()
                if row["underlying"] == underlying
                and row["expiry"] >= ASOF_DATE.isoformat()
                and not row["adjusted"]
                and not row["suspended"]
            }
        )
        selected_expiries[underlying] = exps[:2]

    requested_codes: dict[str, str] = {}
    code_underlying: dict[str, str] = {}
    for underlying, expiries in selected_expiries.items():
        for expiry in expiries:
            yymm = date.fromisoformat(expiry).strftime("%y%m")
            for sid, cp in chain_codes(underlying, yymm).items():
                requested_codes[sid] = cp
                code_underlying[sid] = underlying
    quotes, greeks = fetch_sina_quotes(sorted(requested_codes))

    options: dict[str, list[Option]] = {code: [] for code in UNDERLYINGS}
    failures: dict[str, Any] = {}
    for sid, underlying in code_underlying.items():
        meta = all_meta.get(sid)
        f = quotes.get(sid)
        if not meta or not f or len(f) < 43:
            failures[sid] = {"meta": bool(meta), "quote_fields": len(f or [])}
            continue
        if (
            meta["underlying"] != underlying
            or meta["expiry"] not in selected_expiries[underlying]
            or meta["adjusted"]
            or meta["suspended"]
            or meta["unit"] != 10000
        ):
            continue
        g = greeks.get(sid, [])
        vendor_iv = safe_float(g[9]) if len(g) > 9 else None
        vendor_valid = vendor_iv is not None and 0.005 <= vendor_iv <= 2.0
        opt = Option(
            underlying=underlying,
            exchange=UNDERLYINGS[underlying]["exchange"],
            security_id=sid,
            contract_id=meta["contract_id"],
            name=meta["name"],
            cp=meta["cp"],
            strike=meta["strike"],
            expiry=meta["expiry"],
            unit=meta["unit"],
            bid=safe_float(f[1]) or 0.0,
            ask=safe_float(f[3]) or 0.0,
            bid_qty=safe_int(f[0]),
            ask_qty=safe_int(f[4]),
            last=safe_float(f[2]) or 0.0,
            volume=safe_int(f[41]),
            oi=meta.get("official_oi") or safe_int(f[5]),
            quote_date=f[32] if len(f) > 32 else "",
            adjusted=meta["adjusted"],
            suspended=meta["suspended"],
            official_oi=meta.get("official_oi"),
            vendor_delta=safe_float(g[5]) if vendor_valid else None,
            vendor_gamma=safe_float(g[6]) if vendor_valid else None,
            vendor_theta=safe_float(g[7]) if vendor_valid else None,
            vendor_vega=safe_float(g[8]) if vendor_valid else None,
            vendor_iv=vendor_iv if vendor_valid else None,
            ask_levels=[
                (safe_float(f[i]) or 0.0, safe_int(f[i + 1]))
                for i in (20, 18, 16, 14, 12)
                if len(f) > i + 1 and (safe_float(f[i]) or 0.0) > 0
            ],
            bid_levels=[
                (safe_float(f[i]) or 0.0, safe_int(f[i + 1]))
                for i in (22, 24, 26, 28, 30)
                if len(f) > i + 1 and (safe_float(f[i]) or 0.0) > 0
            ],
        )
        if opt.bid > 0 and opt.ask > opt.bid and opt.unit > 0:
            options[underlying].append(opt)
    return options, {"selected_expiries": selected_expiries, "failures": failures}


def estimate_q_and_greeks(options: dict[str, list[Option]], spots: dict[str, dict[str, Any]]) -> dict[str, dict[str, float]]:
    q_by_group: dict[str, dict[str, float]] = {}
    for underlying, chain in options.items():
        s = spots[underlying]["last"]
        q_by_group[underlying] = {}
        for expiry in sorted({o.expiry for o in chain}):
            t = remaining_years(expiry)
            rows = [o for o in chain if o.expiry == expiry]
            pairs: dict[float, dict[str, Option]] = {}
            for o in rows:
                pairs.setdefault(o.strike, {})[o.cp] = o
            qs = []
            for k, pair in pairs.items():
                c, p = pair.get("C"), pair.get("P")
                if not c or not p or c.rel_spread > 0.08 or p.rel_spread > 0.08:
                    continue
                fwd = (c.mid - p.mid) * math.exp(RISK_FREE * t) + k
                if fwd <= 0:
                    continue
                q = RISK_FREE - math.log(fwd / s) / t
                if -0.05 <= q <= 0.15:
                    qs.append(q)
            q_est = statistics.median(qs) if qs else 0.0
            q_by_group[underlying][expiry] = q_est
            for o in rows:
                o.q = q_est
                iv = implied_vol(o.cp, o.mid, s, o.strike, t, RISK_FREE, q_est)
                if iv is None and o.vendor_iv and 0.01 <= o.vendor_iv <= 2.0:
                    iv = o.vendor_iv
                o.iv = iv
                if iv:
                    g = bs_greeks(o.cp, s, o.strike, t, RISK_FREE, q_est, iv)
                    o.delta, o.gamma, o.theta, o.vega = g["delta"], g["gamma"], g["theta"], g["vega"]
    return q_by_group


def run_chain_checks(options: dict[str, list[Option]], spots: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Run quote-structure checks and mark parity failures before ranking."""
    summary: dict[str, Any] = {}
    tick_tolerance = 0.0002
    for underlying, chain in options.items():
        s = spots[underlying]["last"]
        counts = {
            "contracts": len(chain),
            "hard_quote_fail": 0,
            "monotonic_fail": 0,
            "convexity_warning": 0,
            "parity_fail": 0,
        }
        for o in chain:
            o.arbitrage_ok = True
            o.arbitrage_notes = []
            asks = [row[0] for row in o.ask_levels]
            bids = [row[0] for row in o.bid_levels]
            t = remaining_years(o.expiry)
            q = o.q or 0.0
            intrinsic = (
                max(s * math.exp(-q * t) - o.strike * math.exp(-RISK_FREE * t), 0.0)
                if o.cp == "C"
                else max(o.strike * math.exp(-RISK_FREE * t) - s * math.exp(-q * t), 0.0)
            )
            upper = s * math.exp(-q * t) if o.cp == "C" else o.strike * math.exp(-RISK_FREE * t)
            bad = (
                not (o.bid > 0 and o.ask > o.bid)
                or (asks and any(asks[i] > asks[i + 1] for i in range(len(asks) - 1)))
                or (bids and any(bids[i] < bids[i + 1] for i in range(len(bids) - 1)))
                or o.ask + 0.0001 < intrinsic
                or o.bid - 0.0001 > upper
            )
            if bad:
                o.arbitrage_ok = False
                o.arbitrage_notes.append("报价边界或五档顺序失败")
                counts["hard_quote_fail"] += 1

        for expiry in sorted({o.expiry for o in chain}):
            rows_for_expiry = [o for o in chain if o.expiry == expiry]
            for cp in ("C", "P"):
                rows = sorted((o for o in rows_for_expiry if o.cp == cp), key=lambda x: x.strike)
                for left, right in zip(rows, rows[1:]):
                    violation = left.ask < right.bid if cp == "C" else right.ask < left.bid
                    if violation:
                        for o in (left, right):
                            o.arbitrage_ok = False
                            o.arbitrage_notes.append("执行价单调性失败")
                        counts["monotonic_fail"] += 1
                mids = [o.mid for o in rows]
                for i in range(1, len(rows) - 1):
                    k0, k1, k2 = rows[i - 1].strike, rows[i].strike, rows[i + 1].strike
                    left_slope = (mids[i] - mids[i - 1]) / (k1 - k0)
                    right_slope = (mids[i + 1] - mids[i]) / (k2 - k1)
                    if right_slope < left_slope - 0.002:
                        rows[i].arbitrage_notes.append("中价凸性警告")
                        counts["convexity_warning"] += 1

            calls = {o.strike: o for o in rows_for_expiry if o.cp == "C"}
            puts = {o.strike: o for o in rows_for_expiry if o.cp == "P"}
            t = remaining_years(expiry)
            q = statistics.median([o.q for o in rows_for_expiry if o.q is not None]) if rows_for_expiry else 0.0
            for strike in sorted(set(calls) & set(puts)):
                call, put = calls[strike], puts[strike]
                parity = s * math.exp(-q * t) - strike * math.exp(-RISK_FREE * t)
                lower, upper = call.bid - put.ask, call.ask - put.bid
                if parity < lower - tick_tolerance or parity > upper + tick_tolerance:
                    for o in (call, put):
                        o.arbitrage_ok = False
                        o.arbitrage_notes.append("put-call parity区间不重合")
                    counts["parity_fail"] += 1
        summary[underlying] = counts
    return summary


def fetch_history_and_indicators() -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    indicators: dict[str, dict[str, Any]] = {}
    raw: dict[str, Any] = {}
    for underlying, info in UNDERLYINGS.items():
        symbol = info["symbol"]
        url = f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param={symbol},day,,,120,qfq"
        payload = get(url, referer="https://gu.qq.com/").json()["data"][symbol]
        rows = payload.get("qfqday") or payload.get("day")
        raw[underlying] = rows
        df = pd.DataFrame(rows, columns=["date", "open", "close", "high", "low", "volume"])
        for c in ["open", "close", "high", "low", "volume"]:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        close = df["close"]
        ma = {n: float(close.rolling(n).mean().iloc[-1]) for n in [3, 5, 7, 10, 17, 20, 60]}
        std20 = float(close.rolling(20).std(ddof=0).iloc[-1])
        boll_mid = ma[20]
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        dif = ema12 - ema26
        dea = dif.ewm(span=9, adjust=False).mean()
        macd_hist = 2 * (dif - dea)
        prev_close = close.shift(1)
        tr = pd.concat(
            [df["high"] - df["low"], (df["high"] - prev_close).abs(), (df["low"] - prev_close).abs()], axis=1
        ).max(axis=1)
        atr14_series = tr.ewm(alpha=1 / 14, adjust=False).mean()
        up_move = df["high"].diff()
        down_move = -df["low"].diff()
        plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
        minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0.0)
        atr_sm = tr.ewm(alpha=1 / 14, adjust=False).mean()
        plus_di = 100 * plus_dm.ewm(alpha=1 / 14, adjust=False).mean() / atr_sm
        minus_di = 100 * minus_dm.ewm(alpha=1 / 14, adjust=False).mean() / atr_sm
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
        adx = dx.ewm(alpha=1 / 14, adjust=False).mean()
        last = float(close.iloc[-1])
        z20 = (last - boll_mid) / std20 if std20 > 0 else 0.0
        score = 0
        score += 1 if last > ma[5] else -1
        score += 1 if last > ma[10] else -1
        score += 1 if last > ma[20] else -1
        score += 1 if ma[5] > ma[10] else -1
        score += 1 if float(dif.iloc[-1]) > float(dea.iloc[-1]) else -1
        score += 1 if float(plus_di.iloc[-1]) > float(minus_di.iloc[-1]) else -1
        if z20 > 0.5:
            score += 1
        elif z20 < -0.5:
            score -= 1
        bull = "优先" if score >= 3 else ("禁止" if score <= -3 else "观察")
        bear = "优先" if score <= -3 else ("禁止" if score >= 3 else "观察")
        indicators[underlying] = {
            "date": df["date"].iloc[-1],
            "close": last,
            "ma": ma,
            "boll_mid": boll_mid,
            "boll_upper": boll_mid + 2 * std20,
            "boll_lower": boll_mid - 2 * std20,
            "dif": float(dif.iloc[-1]),
            "dea": float(dea.iloc[-1]),
            "macd_hist": float(macd_hist.iloc[-1]),
            "atr14": float(atr14_series.iloc[-1]),
            "plus_di": float(plus_di.iloc[-1]),
            "minus_di": float(minus_di.iloc[-1]),
            "adx": float(adx.iloc[-1]),
            "z20": z20,
            "volume_ratio20": float(df["volume"].iloc[-1] / df["volume"].rolling(20).mean().iloc[-1]),
            "trend_score": score,
            "bull_permission": bull,
            "bear_permission": bear,
        }
    return indicators, raw


def liq_score(o: Option) -> float:
    spread_component = max(0.0, 100.0 - o.rel_spread * 1000.0)
    oi_component = min(100.0, 20.0 * math.log10(max(o.oi, 1)))
    vol_component = min(100.0, 22.0 * math.log10(max(o.volume, 1)))
    depth_component = min(100.0, 10.0 * math.sqrt(max(min(o.bid_qty, o.ask_qty), 0)))
    return 0.45 * spread_component + 0.25 * oi_component + 0.2 * vol_component + 0.1 * depth_component


def add_business_days(start: date, n: int) -> date:
    cur = start
    added = 0
    while added < n:
        cur += timedelta(days=1)
        if is_trading_day(cur):
            added += 1
    return cur


def walk_book(o: Option, qty: int, side: str) -> float:
    levels = o.ask_levels if side == "ask" else o.bid_levels
    if not levels:
        price = o.ask if side == "ask" else o.bid
        return price * o.unit * qty
    remaining = qty
    total = 0.0
    for price, available in levels:
        take = min(remaining, max(int(available), 0))
        total += price * o.unit * take
        remaining -= take
        if remaining <= 0:
            break
    if remaining > 0:
        raise ValueError(f"{o.security_id} {side} five-level depth cannot fill {qty}")
    return total


def book_has_depth(o: Option, qty: int, side: str) -> bool:
    levels = o.ask_levels if side == "ask" else o.bid_levels
    return bool(levels) and sum(max(int(available), 0) for _, available in levels) >= qty


def leg_entry_cost(o: Option, qty: int) -> float:
    return walk_book(o, qty, "ask")


def leg_book_exit_value(o: Option, qty: int) -> float:
    return walk_book(o, qty, "bid")


def combo_cost(main: Option, insurance: Option, n_main: int, n_ins: int) -> float:
    return leg_entry_cost(main, n_main) + leg_entry_cost(insurance, n_ins)


def combo_exit_value(
    main: Option,
    insurance: Option,
    n_main: int,
    n_ins: int,
    s_new: float,
    horizon_trading_days: int,
    iv_shift: float = 0.0,
) -> float:
    elapsed_date = add_business_days(ASOF_DATE, horizon_trading_days)
    value = 0.0
    for o, qty in ((main, n_main), (insurance, n_ins)):
        elapsed_time = datetime.combine(elapsed_date, VALUATION_TIME.time())
        expiry_time = datetime.combine(date.fromisoformat(o.expiry), datetime.min.time()).replace(hour=15)
        remaining = max((expiry_time - elapsed_time).total_seconds(), 0.0) / (365.0 * 86400.0)
        sigma = max((o.iv or 0.2) + iv_shift, 0.01)
        model_mid = bs_price(o.cp, s_new, o.strike, remaining, RISK_FREE, o.q or 0.0, sigma)
        current_book_exit = leg_book_exit_value(o, qty) / (o.unit * qty)
        conservative = max(model_mid - o.mid + current_book_exit, 0.0)
        value += conservative * o.unit * qty
    return value


def combo_pnl(main: Option, insurance: Option, n_main: int, n_ins: int, s0: float, move: float, horizon: int, iv_shift: float = 0.0) -> float:
    return combo_exit_value(main, insurance, n_main, n_ins, s0 * (1 + move), horizon, iv_shift) - combo_cost(main, insurance, n_main, n_ins)


def combo_greeks(main: Option, insurance: Option, n_main: int, n_ins: int) -> dict[str, float]:
    delta = (main.delta or 0) * n_main * main.unit + (insurance.delta or 0) * n_ins * insurance.unit
    gamma = (main.gamma or 0) * n_main * main.unit + (insurance.gamma or 0) * n_ins * insurance.unit
    theta = ((main.theta or 0) * n_main * main.unit + (insurance.theta or 0) * n_ins * insurance.unit) / 365.0
    vega = ((main.vega or 0) * n_main * main.unit + (insurance.vega or 0) * n_ins * insurance.unit) * 0.01
    reference_unit = sum(o.unit * qty for o, qty in ((main, n_main), (insurance, n_ins))) / max(n_main + n_ins, 1)
    return {
        "delta_rmb_per_0.01": delta * 0.01,
        "delta_units": delta / reference_unit,
        "gamma_rmb_per_yuan2": gamma,
        "theta_rmb_per_day": theta,
        "vega_rmb_per_iv_point": vega,
        "reference_unit": reference_unit,
    }


def source_combo_greeks(main: Option, insurance: Option, n_main: int, n_ins: int) -> dict[str, Any]:
    legs = ((main, n_main), (insurance, n_ins))
    required = ("vendor_delta", "vendor_gamma", "vendor_theta", "vendor_vega")
    if any(any(getattr(o, key) is None for key in required) for o, _ in legs):
        return {"available": False, "source": "行情源Greeks缺失，组合仅使用本地BSM"}
    unit = sum(o.unit * qty for o, qty in legs) / max(n_main + n_ins, 1)
    delta_exposure = sum((o.vendor_delta or 0) * qty * o.unit for o, qty in legs)
    result = {
        "available": True,
        "source": "新浪CON_SO收盘Greeks换算",
        "delta_units": delta_exposure / unit,
        "delta_rmb_per_0.01": delta_exposure * 0.01,
        "gamma_rmb_per_yuan2": sum((o.vendor_gamma or 0) * qty * o.unit for o, qty in legs),
        "theta_rmb_per_day": sum((o.vendor_theta or 0) * qty * o.unit for o, qty in legs) / 365.0,
        "vega_rmb_per_iv_point": sum((o.vendor_vega or 0) * qty * o.unit for o, qty in legs) * 0.01,
        "reference_unit": unit,
    }
    return result


def greek_reconciliation(model: dict[str, float], source: dict[str, Any]) -> dict[str, Any]:
    if not source.get("available"):
        return {"status": "MODEL_ONLY", "label": "源值缺失・仅模型", "max_divergence_pct": None}
    keys = ("delta_units", "gamma_rmb_per_yuan2", "theta_rmb_per_day", "vega_rmb_per_iv_point")
    divergences = {
        key: abs(model[key] - source[key]) / max(abs(source[key]), 1e-9) * 100
        for key in keys
    }
    maximum = max(divergences.values())
    status = "PASS" if maximum <= 15.0 else "REVIEW"
    return {
        "status": status,
        "label": "模型/源值一致" if status == "PASS" else "模型/源值差异显著",
        "max_divergence_pct": maximum,
        "divergence_pct": divergences,
    }


def candidate_score(direction: str, main: Option, ins: Option, n_main: int, n_ins: int, s0: float) -> tuple[float, dict[str, float]]:
    cost = combo_cost(main, ins, n_main, n_ins)
    main_share = leg_entry_cost(main, n_main) / cost
    coverage = abs((ins.delta or 0) * ins.unit * n_ins) / max(abs((main.delta or 0) * main.unit * n_main), 1e-12)
    liquidity = (liq_score(main) + liq_score(ins)) / 2
    delta_fit = max(0.0, 100 - abs(abs(main.delta or 0) - 0.65) * 280)
    insurance_fit = max(0.0, 100 - abs(abs(ins.delta or 0) - 0.27) * 320)
    coverage_fit = max(0.0, 100 - abs(coverage - 0.45) * 180)
    premium_fit = max(0.0, 100 - abs(main_share - 0.75) * 300)
    hedge_fit = 0.3 * delta_fit + 0.2 * insurance_fit + 0.3 * coverage_fit + 0.2 * premium_fit
    g = combo_greeks(main, ins, n_main, n_ins)
    theta_ratio = abs(g["theta_rmb_per_day"]) / max(cost, 1) * 100
    theta_score = max(0.0, 100 - theta_ratio * 180)
    iv_gap = (ins.iv or 0.2) - (main.iv or 0.2)
    iv_score = max(0.0, 100 - max(iv_gap, 0) * 300 - max((main.iv or 0.2) - 0.5, 0) * 100)
    fav_move = 0.03 if direction == "bull" else -0.03
    adverse_move = -0.03 if direction == "bull" else 0.03
    fav = combo_pnl(main, ins, n_main, n_ins, s0, fav_move, 5)
    adverse = combo_pnl(main, ins, n_main, n_ins, s0, adverse_move, 5)
    risk_score = max(0.0, min(100.0, 50 + 35 * fav / max(cost, 1) + 15 * adverse / max(cost, 1)))
    score = 0.30 * liquidity + 0.20 * hedge_fit + 0.15 * theta_score + 0.15 * iv_score + 0.20 * risk_score
    return score, {
        "cost": cost,
        "main_share": main_share,
        "coverage": coverage,
        "liquidity": liquidity,
        "hedge_fit": hedge_fit,
        "theta_score": theta_score,
        "iv_score": iv_score,
        "risk_score": risk_score,
        "fav_t5_3pct": fav,
        "adverse_t5_3pct": adverse,
    }


def screen_direction(
    direction: str,
    chain: list[Option],
    s0: float,
    limit: int = 10,
    require_official: bool = True,
) -> list[dict[str, Any]]:
    next_expiries = sorted({o.expiry for o in chain})
    if len(next_expiries) < 2:
        return []
    near, nxt = next_expiries[:2]
    if direction == "bull":
        # 方向主腿：平值或轻度实值认购；保险腿：平值附近或轻度虚值认沽。
        mains = [
            o for o in chain
            if o.cp == "C" and o.expiry in {near, nxt} and o.dte >= 20 and o.delta is not None
            and 0.50 <= o.delta <= 0.70 and 0.965 <= o.strike / s0 <= 1.00
        ]
        insurance = [
            o for o in chain
            if o.cp == "P" and o.expiry in {near, nxt} and o.delta is not None
            and 0.18 <= abs(o.delta) <= 0.35 and 0.96 <= o.strike / s0 < 1.00
        ]
    else:
        # 镜像：平值或轻度实值认沽作主腿，平值附近或轻度虚值认购作保险。
        mains = [
            o for o in chain
            if o.cp == "P" and o.expiry in {near, nxt} and o.dte >= 20 and o.delta is not None
            and 0.50 <= abs(o.delta) <= 0.70 and 1.00 <= o.strike / s0 <= 1.035
        ]
        insurance = [
            o for o in chain
            if o.cp == "C" and o.expiry in {near, nxt} and o.delta is not None
            and 0.18 <= abs(o.delta) <= 0.35 and 1.00 < o.strike / s0 <= 1.04
        ]
    mains = [
        o for o in mains
        if o.rel_spread <= 0.08 and o.oi >= 300 and o.iv and o.arbitrage_ok
        and not o.adjusted and not o.suspended and (o.official_verified or not require_official)
    ]
    insurance = [
        o for o in insurance
        if o.rel_spread <= 0.08 and o.oi >= 300 and o.iv and o.dte >= 10 and o.arbitrage_ok
        and not o.adjusted and not o.suspended and (o.official_verified or not require_official)
    ]
    combos: list[dict[str, Any]] = []
    for main in mains:
        for ins in insurance:
            for n_main, n_ins in [(1, 1), (2, 1), (3, 1), (3, 2)]:
                if not all(
                    (
                        book_has_depth(main, n_main, "ask"),
                        book_has_depth(main, n_main, "bid"),
                        book_has_depth(ins, n_ins, "ask"),
                        book_has_depth(ins, n_ins, "bid"),
                    )
                ):
                    continue
                score, metrics = candidate_score(direction, main, ins, n_main, n_ins, s0)
                # Hard sanity gates: the strategy must remain directional and insurance cannot dominate.
                g = combo_greeks(main, ins, n_main, n_ins)
                directional = g["delta_units"] > 0.15 if direction == "bull" else g["delta_units"] < -0.15
                if (
                    not directional
                    or not 0.25 <= metrics["coverage"] <= 0.70
                    or not 0.65 <= metrics["main_share"] <= 0.85
                ):
                    continue
                combos.append(
                    {
                        "direction": direction,
                        "strategy_tier": "strict",
                        "is_fallback": False,
                        "main_id": main.security_id,
                        "insurance_id": ins.security_id,
                        "n_main": n_main,
                        "n_ins": n_ins,
                        "score": score,
                        "metrics": metrics,
                        "greeks": g,
                        "source_greeks": source_combo_greeks(main, ins, n_main, n_ins),
                    }
                )
    combos.sort(key=lambda x: (x["score"], x["metrics"]["liquidity"]), reverse=True)
    unique: list[dict[str, Any]] = []
    seen = set()
    for combo in combos:
        key = (combo["main_id"], combo["insurance_id"], combo["n_main"], combo["n_ins"])
        if key not in seen:
            seen.add(key)
            unique.append(combo)
        if len(unique) >= limit:
            break
    for combo in unique:
        combo["greek_reconciliation"] = greek_reconciliation(combo["greeks"], combo["source_greeks"])
    return unique


def screen_fallback_direction(
    direction: str,
    chain: list[Option],
    s0: float,
    limit: int = 10,
    require_official: bool = True,
) -> list[dict[str, Any]]:
    """Build a transparent one-strike fallback only when strict screening is empty.

    The main leg uses the nearest listed ITM strike (never OTM); the insurance leg
    uses the opposite option at the same strike, which is necessarily OTM.  The
    fallback relaxes Delta/premium-share/coverage fit only.  Data, expiry,
    liquidity, depth and no-arbitrage gates remain unchanged.
    """
    expiries = sorted({o.expiry for o in chain})[:2]
    if len(expiries) < 2:
        return []

    by_expiry_cp_strike = {(o.expiry, o.cp, o.strike): o for o in chain}
    combos: list[dict[str, Any]] = []
    main_cp = "C" if direction == "bull" else "P"
    insurance_cp = "P" if direction == "bull" else "C"

    for main_expiry in expiries:
        strikes = sorted(
            {
                o.strike
                for o in chain
                if o.expiry == main_expiry and o.cp == main_cp and o.dte >= 20
            }
        )
        if direction == "bull":
            eligible_strikes = [strike for strike in strikes if strike < s0]
            main_strike = max(eligible_strikes, default=None)
        else:
            eligible_strikes = [strike for strike in strikes if strike > s0]
            main_strike = min(eligible_strikes, default=None)
        if main_strike is None:
            continue

        main = by_expiry_cp_strike.get((main_expiry, main_cp, main_strike))
        if main is None:
            continue
        for insurance_expiry in expiries:
            ins = by_expiry_cp_strike.get((insurance_expiry, insurance_cp, main_strike))
            if ins is None:
                continue
            legs = (main, ins)
            if any(
                o.bid <= 0
                or o.ask <= o.bid
                or o.rel_spread > 0.08
                or o.oi < 300
                or not o.iv
                or not o.arbitrage_ok
                or o.adjusted
                or o.suspended
                or (require_official and not o.official_verified)
                for o in legs
            ):
                continue
            if main.dte < 20 or ins.dte < 10:
                continue
            if not all(
                (
                    book_has_depth(main, 1, "ask"),
                    book_has_depth(main, 1, "bid"),
                    book_has_depth(ins, 1, "ask"),
                    book_has_depth(ins, 1, "bid"),
                )
            ):
                continue

            score, metrics = candidate_score(direction, main, ins, 1, 1, s0)
            greeks = combo_greeks(main, ins, 1, 1)
            directional = greeks["delta_units"] > 0 if direction == "bull" else greeks["delta_units"] < 0
            if not directional:
                continue
            combos.append(
                {
                    "direction": direction,
                    "strategy_tier": "fallback",
                    "is_fallback": True,
                    "fallback_reason": (
                        "严格组合为空；采用最近一档实值主腿＋同执行价虚值保险腿（1:1），"
                        "仅作兜底观察，不进入本时点总首选。"
                    ),
                    "main_id": main.security_id,
                    "insurance_id": ins.security_id,
                    "n_main": 1,
                    "n_ins": 1,
                    "score": score,
                    "metrics": metrics,
                    "greeks": greeks,
                    "source_greeks": source_combo_greeks(main, ins, 1, 1),
                }
            )

    combos.sort(key=lambda x: (x["score"], x["metrics"]["liquidity"]), reverse=True)
    unique: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for combo in combos:
        key = (combo["main_id"], combo["insurance_id"])
        if key in seen:
            continue
        seen.add(key)
        combo["greek_reconciliation"] = greek_reconciliation(combo["greeks"], combo["source_greeks"])
        unique.append(combo)
        if len(unique) >= limit:
            break
    return unique


def fetch_official_sse_snapshot(opt: Option) -> dict[str, Any] | None:
    url = (
        f"http://yunhq.sse.com.cn:32041/v1/sho/snap/{opt.security_id}?select="
        "code,name,last,open,high,low,volume,amount,bid,ask,prev_close,presetpx,change,chg_rate,amp_rate,open_interest,num_trades,exepx,contractid"
    )
    try:
        data = get(url, referer="https://www.sse.com.cn/assortment/options/quote/").json()
        snap = data.get("snap")
        if not snap:
            return None
        return {
            "date": str(data["date"]),
            "time": f"{int(data['time']):06d}",
            "bid": float(snap[8][0]),
            "bid_qty": int(snap[8][1]),
            "ask": float(snap[9][0]),
            "ask_qty": int(snap[9][1]),
            "last": float(snap[2]),
            "volume": int(snap[6]),
            "oi": int(snap[15]),
        }
    except Exception:  # noqa: BLE001
        return None


def fetch_eastmoney_last(opt: Option) -> float | None:
    if opt.exchange != "SZSE":
        return None
    fields = "f43,f57,f58,f60,f161"
    url = f"https://push2.eastmoney.com/api/qt/stock/get?secid=12.{opt.security_id}&fields={fields}"
    try:
        data = get(url, referer="https://quote.eastmoney.com/").json().get("data")
        if not data or data.get("f43") is None:
            return None
        return data["f43"] / 10000.0
    except Exception:  # noqa: BLE001
        return None


def fetch_official_szse_snapshot(opt: Option) -> dict[str, Any] | None:
    url = (
        "https://www.szse.cn/api/market/ssjjhq/getTimeData?"
        f"marketId=70&moduleType=realoption&code={opt.security_id}"
    )
    try:
        payload = get(url, referer="https://www.szse.cn/option/quotation/contract/realtime/").json()
        data = payload.get("data") or {}
        levels = data.get("sellbuy5") or []
        if payload.get("code") != "0" or len(levels) < 10:
            return None
        asks = [(float(x["price"]), int(x.get("volume") or 0)) for x in levels[:5]]
        bids = [(float(x["price"]), int(x.get("volume") or 0)) for x in levels[5:10]]
        return {
            "date": str(data.get("marketTime", ""))[:10],
            "time": str(data.get("marketTime", ""))[11:19],
            "bid": bids[0][0],
            "bid_qty": bids[0][1],
            "ask": asks[0][0],
            "ask_qty": asks[0][1],
            "bid_levels": bids,
            "ask_levels": asks,
            "last": safe_float(data.get("now")),
            "volume": safe_int(data.get("volume")),
        }
    except Exception:  # noqa: BLE001
        return None


def apply_official_snapshot(opt: Option) -> bool:
    snap = fetch_official_sse_snapshot(opt) if opt.exchange == "SSE" else fetch_official_szse_snapshot(opt)
    if not snap:
        opt.arbitrage_ok = False
        opt.arbitrage_notes.append("候选腿缺官方盘口复核")
        return False
    opt.official_bid, opt.official_ask = snap["bid"], snap["ask"]
    raw_time = str(snap.get("time") or "")
    if opt.exchange == "SSE" and raw_time.isdigit():
        raw_time = f"{raw_time[:2]}:{raw_time[2:4]}:{raw_time[4:6]}"
    opt.official_time = f"{snap.get('date', '')} {raw_time}".strip()
    opt.official_verified = abs(opt.bid - snap["bid"]) <= 0.0001 and abs(opt.ask - snap["ask"]) <= 0.0001
    if not opt.official_verified:
        opt.arbitrage_ok = False
        opt.arbitrage_notes.append("官方与独立源买卖一不一致")
        return False
    opt.volume = safe_int(snap.get("volume")) or opt.volume
    opt.official_oi = safe_int(snap.get("oi")) or opt.official_oi
    opt.oi = opt.official_oi or opt.oi
    opt.bid_qty = safe_int(snap.get("bid_qty")) or opt.bid_qty
    opt.ask_qty = safe_int(snap.get("ask_qty")) or opt.ask_qty
    if snap.get("bid_levels"):
        opt.bid_levels = snap["bid_levels"]
    if snap.get("ask_levels"):
        opt.ask_levels = snap["ask_levels"]
    return True


def scenario_bundle(combo: dict[str, Any], by_id: dict[str, Option], s0: float) -> dict[str, Any]:
    main, ins = by_id[combo["main_id"]], by_id[combo["insurance_id"]]
    nm, ni = combo["n_main"], combo["n_ins"]
    cost = combo_cost(main, ins, nm, ni)
    table: dict[str, dict[str, float]] = {}
    for pct in range(-9, 10):
        table[str(pct)] = {
            "t0": combo_pnl(main, ins, nm, ni, s0, pct / 100, 0),
            "t3": combo_pnl(main, ins, nm, ni, s0, pct / 100, 3),
            "t5": combo_pnl(main, ins, nm, ni, s0, pct / 100, 5),
        }
    iv_stress = {
        str(pp): combo_pnl(main, ins, nm, ni, s0, 0.0, 0, pp / 100) for pp in [-5, -2, 2, 5]
    }
    grid = []
    for i in range(-150, 151):
        move = i / 1000
        grid.append((move, combo_pnl(main, ins, nm, ni, s0, move, 5)))
    worst_move, worst_pnl = min(grid, key=lambda x: x[1])
    breakevens: list[float] = []
    if main.expiry == ins.expiry:
        expiry_date = date.fromisoformat(main.expiry)
        expiry_days = 0
        cur = ASOF_DATE
        while cur < expiry_date:
            cur += timedelta(days=1)
            if is_trading_day(cur):
                expiry_days += 1
        expiry_grid = []
        for i in range(-300, 301):
            move = i / 1000
            expiry_grid.append((move, combo_pnl(main, ins, nm, ni, s0, move, expiry_days)))
        for (m1, p1), (m2, p2) in zip(expiry_grid, expiry_grid[1:]):
            if p1 == 0:
                breakevens.append(m1)
            elif p1 * p2 < 0:
                breakevens.append(m1 + (m2 - m1) * (-p1) / (p2 - p1))
        breakeven_status = "CALCULATED"
        breakeven_note = "同月组合，按共同到期日模型计算"
    else:
        breakeven_status = "PATH_DEPENDENT"
        breakeven_note = "跨月组合：近月腿先到期，整体回本点依赖到期前路径，不提供伪精确数值"
    return {
        "cost": cost,
        "roundtrip_now": cost - leg_book_exit_value(main, nm) - leg_book_exit_value(ins, ni),
        "table": table,
        "iv_stress": iv_stress,
        "worst_t5_move": worst_move,
        "worst_t5_pnl": worst_pnl,
        "expiry_breakevens": breakevens,
        "breakeven_status": breakeven_status,
        "breakeven_note": breakeven_note,
        "max_premium_risk": cost,
    }


def money(x: float) -> str:
    sign = "+" if x > 0 else ""
    return f"{sign}{x:,.0f}"


def pct(x: float) -> str:
    return f"{x * 100:.1f}%"


def option_label(o: Option, qty: int) -> str:
    return f"{qty}×{o.name}({o.security_id})"


def build_markdown(
    spots: dict[str, dict[str, Any]],
    indicators: dict[str, dict[str, Any]],
    options: dict[str, list[Option]],
    selections: dict[str, dict[str, Any]],
    q_by_group: dict[str, dict[str, float]],
) -> str:
    lines: list[str] = []
    lines.append("# 五标的ETF期权方向性双买报告")
    lines.append("")
    lines.append(f"> 手动触发时间：{RUN_AT.strftime('%Y-%m-%d %H:%M:%S %z')}；数据：2026-08-07收盘后最近快照（非实时）。")
    lines.append("> 建仓成本按卖一、即时退出按买一；模型测算不含券商手续费，已按当前半价差保守扣减退出值。")
    lines.append("")
    lines.append("## 一屏摘要")
    lines.append("")
    lines.append("|标的|收盘/涨跌|趋势许可（多/空）|最佳偏多|成本|最佳偏空|成本|数据质量|结论|")
    lines.append("|---|---:|---|---|---:|---|---:|---|---|")
    for code, info in UNDERLYINGS.items():
        spot, trend, sel = spots[code], indicators[code], selections[code]
        by_id = {o.security_id: o for o in options[code]}
        bull = sel.get("bull")
        bear = sel.get("bear")
        if bull:
            bm, bi = by_id[bull["main_id"]], by_id[bull["insurance_id"]]
            bull_text = f"{bull['n_main']}购主×{bm.strike:g}+{bull['n_ins']}沽保×{bi.strike:g}"
            bull_cost = f"{bull['scenario']['cost']:,.0f}"
        else:
            bull_text, bull_cost = "无合格组合", "—"
        if bear:
            bm, bi = by_id[bear["main_id"]], by_id[bear["insurance_id"]]
            bear_text = f"{bear['n_main']}沽主×{bm.strike:g}+{bear['n_ins']}购保×{bi.strike:g}"
            bear_cost = f"{bear['scenario']['cost']:,.0f}"
        else:
            bear_text, bear_cost = "无合格组合", "—"
        conclusion = sel["conclusion"]
        lines.append(
            f"|{code} {info['name']}|{spot['last']:.3f} / {spot['pct']:+.2f}%|{trend['bull_permission']}/{trend['bear_permission']}|{bull_text}|{bull_cost}|{bear_text}|{bear_cost}|{sel['quality']}|{conclusion}|"
        )
    lines.append("")
    lines.append(f"**本时点总首选：{selections['total_first_choice']}**")
    lines.append("")
    lines.append("## 数据对账")
    lines.append("")
    lines.append("|标的|腾讯收盘|腾讯时间|第二源/收盘|第二源时间|差异|近月/次月|")
    lines.append("|---|---:|---|---:|---|---:|---|")
    for code in UNDERLYINGS:
        spot = spots[code]
        exps = sorted({o.expiry for o in options[code]})
        lines.append(
            f"|{code}|{spot['last']:.3f}|{spot['time']}|{spot['secondary_source']} {spot['secondary_last']:.3f}|{spot['secondary_time']}|{spot['source_diff']:.4f}|{' / '.join(exps)}|"
        )
    lines.append("")
    lines.append("沪市合约：上交所当日主数据＋官方收盘五档＋新浪收盘五档逐腿核对；159915：深交所当日主数据＋官方15:00五档＋新浪五档逐腿核对。质量等级均指收盘冻结快照，不代表此刻实时盘口。")
    lines.append("")

    for code, info in UNDERLYINGS.items():
        lines.append(f"## {code} {info['name']}")
        lines.append("")
        spot, trend, sel = spots[code], indicators[code], selections[code]
        lines.append(
            f"收盘 {spot['last']:.3f}（{spot['pct']:+.2f}%），MA5/10/20={trend['ma'][5]:.3f}/{trend['ma'][10]:.3f}/{trend['ma'][20]:.3f}，"
            f"MACD柱={trend['macd_hist']:+.4f}，ADX={trend['adx']:.1f}，+DI/-DI={trend['plus_di']:.1f}/{trend['minus_di']:.1f}，"
            f"ATR14={trend['atr14']:.3f}，Z20={trend['z20']:+.2f}，量比20日={trend['volume_ratio20']:.2f}。"
        )
        lines.append(f"方向许可：偏多 **{trend['bull_permission']}**；偏空 **{trend['bear_permission']}**。数据质量：**{sel['quality']}**。")
        lines.append("")
        by_id = {o.security_id: o for o in options[code]}
        for key, title in (("bull", "偏多最佳"), ("bear", "偏空最佳")):
            combo = sel.get(key)
            lines.append(f"### {title}")
            lines.append("")
            if not combo:
                lines.append("无通过流动性、Delta、期限和数据门禁的组合。")
                lines.append("")
                continue
            main, ins = by_id[combo["main_id"]], by_id[combo["insurance_id"]]
            nm, ni = combo["n_main"], combo["n_ins"]
            scen = combo["scenario"]
            lines.append(
                f"**{option_label(main, nm)} + {option_label(ins, ni)}**；评分 {combo['score']:.1f}/100；卖一成本 {scen['cost']:,.0f} 元；"
                f"即时往返摩擦约 {scen['roundtrip_now']:,.0f} 元；主腿权利金占比 {pct(combo['metrics']['main_share'])}；保险Delta覆盖 {pct(combo['metrics']['coverage'])}。"
            )
            lines.append("")
            lines.append("|腿|到期|买一/卖一|价差|量/持仓|IV源/模型|Delta源/模型|Gamma模型|Theta元/日|Vega元/IV点|核验|")
            lines.append("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|")
            for o, qty, role in ((main, nm, "主腿"), (ins, ni, "保险")):
                theta_rmb = (o.theta or 0) / 365 * o.unit * qty
                vega_rmb = (o.vega or 0) * 0.01 * o.unit * qty
                vendor_iv_text = f"{o.vendor_iv*100:.1f}%" if o.vendor_iv and o.vendor_iv > 0.001 else "—"
                vendor_delta_text = f"{o.vendor_delta:+.3f}" if o.vendor_iv and o.vendor_delta is not None and abs(o.vendor_delta) < 0.99 else "—"
                verify = (
                    f"{o.exchange} {o.official_time}"
                    if o.official_time
                    else (f"东财last={o.eastmoney_last:.4f}" if o.eastmoney_last is not None else "单一盘口源")
                )
                lines.append(
                    f"|{role} {qty}×{o.name} {o.security_id}|{o.expiry}|{o.bid:.4f}/{o.ask:.4f}|{o.rel_spread*100:.1f}%|{o.volume:,}/{o.oi:,}|{vendor_iv_text}/{(o.iv or 0)*100:.1f}%|{vendor_delta_text}/{(o.delta or 0):+.3f}|{(o.gamma or 0):.3f}|{theta_rmb:+.0f}|{vega_rmb:+.0f}|{verify}|"
                )
            g = combo["greeks"]
            lines.append("")
            lines.append(
                f"组合Greeks：ETF每变动0.01元初始Delta影响 {g['delta_rmb_per_0.01']:+.0f} 元；Theta {g['theta_rmb_per_day']:+.0f} 元/自然日；"
                f"Vega {g['vega_rmb_per_iv_point']:+.0f} 元/IV变化1个百分点。T+5最危险位置约 {scen['worst_t5_move']*100:+.1f}%，模型损益 {money(scen['worst_t5_pnl'])} 元；"
                f"最大权利金风险 {scen['max_premium_risk']:,.0f} 元。"
            )
            if scen["expiry_breakevens"]:
                be = "、".join(f"{spot['last']*(1+x):.3f}({x*100:+.1f}%)" for x in scen["expiry_breakevens"])
                lines.append(f"统一按较晚到期日估算的模型回本位置：{be}。跨月腿在较早到期后需重建，因此仅作风险定位。")
            lines.append(
                "IV同步冲击（标的不变、T+0）："
                + "，".join(f"{int(pp):+d}pp {money(v)}元" for pp, v in sorted(((float(k), val) for k, val in scen["iv_stress"].items()), key=lambda x: x[0]))
                + "。"
            )
            lines.append("")
            if combo.get("alternatives"):
                alt_text = []
                for alt in combo["alternatives"][:2]:
                    am, ai = by_id[alt["main_id"]], by_id[alt["insurance_id"]]
                    alt_text.append(f"{alt['n_main']}×{am.strike:g}{am.cp}+{alt['n_ins']}×{ai.strike:g}{ai.cp}（{alt['score']:.1f}分）")
                lines.append("落选候选：" + "；".join(alt_text) + "。主要差异为价差、保险覆盖或Theta/成本性价比。")
                lines.append("")

        bull, bear = sel.get("bull"), sel.get("bear")
        if bull and bear:
            lines.append("### 标的涨跌情景损益（元）")
            lines.append("")
            lines.append("|标的变动|偏多T+0|偏多T+3|偏多T+5|偏空T+0|偏空T+3|偏空T+5|")
            lines.append("|---:|---:|---:|---:|---:|---:|---:|")
            for p in range(-9, 10):
                b = bull["scenario"]["table"][str(p)]
                d = bear["scenario"]["table"][str(p)]
                lines.append(f"|{p:+d}%|{money(b['t0'])}|{money(b['t3'])}|{money(b['t5'])}|{money(d['t0'])}|{money(d['t3'])}|{money(d['t5'])}|")
            lines.append("")
        lines.append(
            "纪律：组合亏损-10%警戒、-15%减仓、-20%止损；2天未走强收紧，3天横盘减大部，最长5个交易日重评。"
        )
        lines.append("")

    lines.append("## 方法、限制与直接数据源")
    lines.append("")
    lines.append("- 定价：各腿按同步中价反解BSM隐含波动率；短端无风险利率假设1.15%，ETF隐含持有收益率由同到期购沽平价中位数估计。T+3/T+5分别按5/7个自然日衰减。")
    lines.append("- Greeks口径：表内“源”是新浪原始指标，“模型”是按可成交中价反推后的统一口径。部分沪市源IV/Delta与市场权利金明显不匹配，因此评分和损益只使用模型值；159915的新浪Greeks为空/异常，同样只使用本地反推值，并以深交所盘后风险指标复核量纲。")
    lines.append("- 场景：每个节点逐腿完整非线性重估，未使用Delta直线外推，也未在到期前只算内在价值。")
    lines.append("- [上交所当日合约主数据](http://query.sse.com.cn/commonQuery.do?isPagination=false&expireDate=&securityId=&sqlId=SSE_ZQPZ_YSP_GGQQZSXT_XXPL_DRHY_SEARCH_L)；[上交所期权行情服务说明](https://www.sseinfo.com/services/assortment/options/)；[深交所当日合约页](https://www.szse.cn/option/quotation/contract/daycontract/index.html)；[深交所期权五档接口](https://www.szse.cn/api/market/ssjjhq/getTimeData?marketId=70&moduleType=realoption&code=90007075)；[腾讯现货行情](https://qt.gtimg.cn/)；[新浪期权行情](https://stock.finance.sina.com.cn/option/quotes.html)。")
    lines.append("- 免费公开接口无交易所级SLA；本次A级仅表示官方收盘五档与独立行情源逐腿一致。收盘后盘口仅代表最近收盘快照，次日开盘不可直接照价成交。")
    lines.append("- 模型测算≠实际成交保证；本报告为非个性化研究信息，不构成投资建议。")
    return "\n".join(lines) + "\n"


def main() -> None:
    global ASOF_DATE, VALUATION_TIME
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)
    spots, spot_raw = fetch_spots()
    primary_dates = {parse_source_datetime(spot["time"]).date() for spot in spots.values() if parse_source_datetime(spot["time"])}
    secondary_dates = {
        parse_source_datetime(spot["secondary_time"]).date()
        for spot in spots.values()
        if parse_source_datetime(spot["secondary_time"])
    }
    if len(primary_dates) != 1:
        raise RuntimeError(f"五标的主源交易日不一致：{sorted(primary_dates)}")
    ASOF_DATE = next(iter(primary_dates))
    RISK_FREE_META["as_of"] = ASOF_DATE.isoformat()
    source_datetimes = [parse_source_datetime(spot["time"]) for spot in spots.values()]
    latest_source_time = max(value for value in source_datetimes if value is not None)
    if ASOF_DATE < RUN_AT.date() or latest_source_time.time() >= datetime.strptime("15:00", "%H:%M").time():
        VALUATION_TIME = datetime.combine(ASOF_DATE, datetime.strptime("15:00", "%H:%M").time())
    else:
        VALUATION_TIME = RUN_AT.replace(tzinfo=None)
    source_dates_match = secondary_dates == {ASOF_DATE}

    sse_meta = fetch_sse_metadata()
    sz_meta = fetch_szse_metadata()
    options, chain_meta = build_options(spots, sse_meta, sz_meta)
    q_by_group = estimate_q_and_greeks(options, spots)
    chain_checks = run_chain_checks(options, spots)
    indicators, history_raw = fetch_history_and_indicators()

    # 第一遍只建立宽候选池；把池内所有可能入选腿先用官方盘口/OI复核，再最终排名。
    candidate_legs: dict[str, Option] = {}
    for code in UNDERLYINGS:
        by_id = {o.security_id: o for o in options[code]}
        for direction in ("bull", "bear"):
            for combo in screen_direction(direction, options[code], spots[code]["last"], limit=200, require_official=False):
                candidate_legs[combo["main_id"]] = by_id[combo["main_id"]]
                candidate_legs[combo["insurance_id"]] = by_id[combo["insurance_id"]]
            for combo in screen_fallback_direction(direction, options[code], spots[code]["last"], limit=20, require_official=False):
                candidate_legs[combo["main_id"]] = by_id[combo["main_id"]]
                candidate_legs[combo["insurance_id"]] = by_id[combo["insurance_id"]]
    for option in candidate_legs.values():
        apply_official_snapshot(option)

    selections: dict[str, dict[str, Any]] = {}
    for code in UNDERLYINGS:
        chain = options[code]
        by_id = {o.security_id: o for o in chain}
        bull_strict = screen_direction("bull", chain, spots[code]["last"])
        bear_strict = screen_direction("bear", chain, spots[code]["last"])
        bull_candidates = bull_strict or screen_fallback_direction("bull", chain, spots[code]["last"])
        bear_candidates = bear_strict or screen_fallback_direction("bear", chain, spots[code]["last"])
        sel: dict[str, Any] = {}
        for key, candidates in (("bull", bull_candidates), ("bear", bear_candidates)):
            if not candidates:
                sel[key] = None
                continue
            best = candidates[0]
            best["alternatives"] = candidates[1:3]
            best["scenario"] = scenario_bundle(best, by_id, spots[code]["last"])
            sel[key] = best
        selections[code] = sel

    history_dates_match = all(indicators[code]["date"] == ASOF_DATE.isoformat() for code in UNDERLYINGS)
    trading_day_verified = is_trading_day(ASOF_DATE) and source_dates_match and history_dates_match
    for code in UNDERLYINGS:
        sel = selections[code]
        by_id = {o.security_id: o for o in options[code]}
        selected_combos = [sel.get(key) for key in ("bull", "bear") if sel.get(key)]
        has_fallback = any(combo.get("is_fallback", False) for combo in selected_combos)
        sel["has_fallback"] = has_fallback
        price_valid = bool(selected_combos) and spots[code]["validated"] and spots[code]["volume_validated"] and trading_day_verified
        model_valid = bool(selected_combos) and RISK_FREE_META["verified"]
        for key in ("bull", "bear"):
            combo = sel.get(key)
            if not combo:
                continue
            for oid in (combo["main_id"], combo["insurance_id"]):
                o = by_id[oid]
                price_valid = price_valid and o.official_verified and o.unit == 10000 and not o.adjusted and not o.suspended
                model_valid = model_valid and o.arbitrage_ok
            model_valid = model_valid and combo["greek_reconciliation"]["status"] == "PASS"
        sel["price_quality"] = "A（官方元数据＋双源收盘报价一致）" if price_valid else "C（价格门禁未完整通过）"
        sel["model_quality"] = "A（模型与源值一致）" if model_valid else "B（Greeks需复核／利率为假设）"
        sel["quality"] = (
            "B（兜底观察・非首选）"
            if price_valid and has_fallback
            else "A（价格与模型均通过）"
            if price_valid and model_valid
            else "B（价格已核验・模型观察）"
            if price_valid
            else "C（不推荐）"
        )
        trend = indicators[code]
        if has_fallback:
            sel["conclusion"] = "兜底观察，不执行"
        elif not sel["quality"].startswith("A"):
            sel["conclusion"] = "观察，不执行"
        elif trend["bull_permission"] == "优先" and sel.get("bull"):
            sel["conclusion"] = "偏多优先"
        elif trend["bear_permission"] == "优先" and sel.get("bear"):
            sel["conclusion"] = "偏空优先"
        else:
            sel["conclusion"] = "观望"

    ranked = []
    for code in UNDERLYINGS:
        sel, trend = selections[code], indicators[code]
        if not sel["quality"].startswith("A"):
            continue
        if trend["bull_permission"] == "优先" and sel.get("bull") and not sel["bull"].get("is_fallback", False):
            ranked.append((sel["bull"]["score"], code, "偏多", sel["bull"]))
        if trend["bear_permission"] == "优先" and sel.get("bear") and not sel["bear"].get("is_fallback", False):
            ranked.append((sel["bear"]["score"], code, "偏空", sel["bear"]))
    if ranked:
        ranked.sort(reverse=True, key=lambda x: x[0])
        score, code, direction, combo = ranked[0]
        by_id = {o.security_id: o for o in options[code]}
        main_o, ins_o = by_id[combo["main_id"]], by_id[combo["insurance_id"]]
        selections["total_first_choice"] = (
            f"{code} {direction}：{combo['n_main']}×{main_o.name} + {combo['n_ins']}×{ins_o.name}（研究评分{score:.1f}，仅作次日重新报价前候选）"
        )
    else:
        selections["total_first_choice"] = "本时点无A级且方向许可的可执行首选"

    report = build_markdown(spots, indicators, options, selections, q_by_group)
    report_path = OUTPUTS / f"ETF期权最新报告_{ASOF_DATE.isoformat()}_{capture_slot_for(VALUATION_TIME).replace(':', '')}.md"
    report_path.write_text(report, encoding="utf-8")

    serializable_options = {code: [asdict(o) for o in chain] for code, chain in options.items()}
    payload = {
        "run_at": RUN_AT.isoformat(),
        "asof_date": ASOF_DATE.isoformat(),
        "risk_free": RISK_FREE,
        "risk_free_meta": RISK_FREE_META,
        "trading_day_verified": trading_day_verified,
        "snapshot_label": "历史最近快照／非实时 · 收盘冻结" if ASOF_DATE < RUN_AT.date() else "当日实际抓取快照",
        "quality_label": "价格A｜模型B（仅观察）" if all(selections[c]["price_quality"].startswith("A") for c in UNDERLYINGS) else "数据门禁未完整通过",
        "market_stage": "收盘冻结" if VALUATION_TIME.hour >= 15 else "交易时段实际抓取",
        "capture_slot": capture_slot_for(VALUATION_TIME),
        "chain_checks": chain_checks,
        "spots": spots,
        "spot_raw": spot_raw,
        "chain_meta": chain_meta,
        "q_by_group": q_by_group,
        "indicators": indicators,
        "options": serializable_options,
        "selections": selections,
    }
    archive_dir = ROOT / "data" / "snapshots" / ASOF_DATE.isoformat()
    archive_dir.mkdir(parents=True, exist_ok=True)
    archive_name = capture_slot_for(VALUATION_TIME).replace(":", "") + ".json"
    archive_path = archive_dir / archive_name
    slot_definitions = [
        ("09:45", "开盘确认"), ("11:30", "午间收盘"), ("13:30", "午后确认"),
        ("14:30", "尾盘观察"), ("15:00", "收盘归档"),
    ]
    capture_slots = []
    for slot, label in slot_definitions:
        slot_path = archive_dir / f"{slot.replace(':', '')}.json"
        is_current = slot == payload["capture_slot"]
        available = slot_path.exists() or is_current
        captured_at = payload["run_at"] if is_current else None
        if slot_path.exists() and not is_current:
            try:
                archived_payload = json.loads(slot_path.read_text(encoding="utf-8"))
                captured_at = archived_payload.get("run_at")
            except (OSError, json.JSONDecodeError):
                captured_at = None
        capture_slots.append(
            {
                "time": slot,
                "label": label,
                "available": available and captured_at is not None,
                "capturedAt": captured_at,
            }
        )
    payload["capture_slots"] = capture_slots
    (WORK / "option_report_data.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    data_dir = ROOT / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "option_report_data.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    archive_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"report": str(report_path), "summary": {c: {k: v for k, v in selections[c].items() if k in {"quality", "conclusion"}} for c in UNDERLYINGS}, "total_first_choice": selections["total_first_choice"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
